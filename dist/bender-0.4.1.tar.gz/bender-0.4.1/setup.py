# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bender', 'bender.jira']

package_data = \
{'': ['*']}

install_requires = \
['click>=7.1.1,<8.0.0',
 'colorama>=0.4.3,<0.5.0',
 'pyyaml>=5.3.1,<6.0.0',
 'requests>=2.23.0,<3.0.0']

entry_points = \
{'console_scripts': ['bender = bender.cli:cli',
                     'jbender = bender.jira.cli:cli']}

setup_kwargs = {
    'name': 'bender',
    'version': '0.4.1',
    'description': 'CLI admin interface for Atlassian Jira',
    'long_description': None,
    'author': 'Charles Moreland',
    'author_email': 'morelanc@ohsu.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
