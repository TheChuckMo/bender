import pkg_resources

APP_NAME = 'bender'
APP_VERSION = pkg_resources.get_distribution(APP_NAME).version
