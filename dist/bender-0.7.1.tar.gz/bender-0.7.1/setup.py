# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bender', 'bender.confluence', 'bender.crowd', 'bender.jira']

package_data = \
{'': ['*']}

install_requires = \
['click>=7.1.1,<8.0.0',
 'colorama>=0.4.3,<0.5.0',
 'jsonpath-ng>=1.5.1,<2.0.0',
 'mkautodoc>=0.1.0,<0.2.0',
 'pyyaml>=5.3.1,<6.0.0',
 'requests>=2.23.0,<3.0.0',
 'requests_toolbelt>=0.9.1,<0.10.0']

entry_points = \
{'console_scripts': ['bendconfluence = bender.confluence.cli:cli',
                     'bendcrowd = bender.crowd.cli:cli',
                     'bender = bender.cli:cli',
                     'bendjira = bender.jira.cli:cli']}

setup_kwargs = {
    'name': 'bender',
    'version': '0.7.1',
    'description': 'CLI admin interface for Atlassian apps.',
    'long_description': None,
    'author': 'Charles Moreland',
    'author_email': 'morelanc@ohsu.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.8,<4.0.0',
}


setup(**setup_kwargs)
